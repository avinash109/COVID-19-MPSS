package org.covid19mpss.handler.events;

import static org.junit.Assert.assertNull;

import java.util.Map;

import org.junit.Test;
import org.covid19mpss.BaseTest;
import org.covid19mpss.TestIdentityManager;
import org.covid19mpss.model.Event;
import org.covid19mpss.model.Position;

public class IgnitionEventHandlerTest extends BaseTest {
    
    @Test
    public void testIgnitionEventHandler() {
        
        IgnitionEventHandler ignitionEventHandler = new IgnitionEventHandler(new TestIdentityManager());
        
        Position position = new Position();
        position.set(Position.KEY_IGNITION, true);
        position.setValid(true);
        Map<Event, Position> events = ignitionEventHandler.analyzePosition(position);
        assertNull(events);
    }

}
