<?php

	require_once("config.php");

	$db = new Database();
	$db->connect();

	$response = array();

	$upload_directory = "uploads/";

	function distance($lat1, $lon1, $lat2, $lon2, $unit) {
	  if (($lat1 == $lat2) && ($lon1 == $lon2)) {
	    return 0;
	  }
	  else {
	    $theta = $lon1 - $lon2;
	    $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
	    $dist = acos($dist);
	    $dist = rad2deg($dist);
	    $miles = $dist * 60 * 1.1515;
	    $unit = strtoupper($unit);

	    if ($unit == "M") {
	      return ($miles * 1.609344);
	    } else {
	      return $miles;
	    }
	  }
	}

	if(isset($_POST['check_infaction']) AND $_POST['check_infaction']==1){

		if (!isset($_POST['person_name']) || empty($_POST['person_name']) 
			|| !isset($_POST['person_mobile_no']) || empty($_POST['person_mobile_no']) 
			|| !isset($_POST['person_age']) || empty($_POST['person_age']) 
			|| !isset($_POST['person_address']) || empty($_POST['person_address']) 
			|| !isset($_FILES['file']['name']) || empty($_FILES['file']['name'])) {

			$response['error'] = "true";
			$response['message'] = "All fields are required.";
			print_r(json_encode($response));
			return;
		}

		$person_name = $db->escapeString($_POST['person_name']);
		$person_mobile_no = $db->escapeString($_POST['person_mobile_no']);
		$person_age = $db->escapeString($_POST['person_age']);
		$person_address = $db->escapeString($_POST['person_address']);

		$data = array(
				'name'  => $person_name,
				'age'	 => $person_age,
				'mobile_no' => $person_mobile_no,
				'address' => $person_address,
				'medical_status' => '0'
			);
		$sql = $db->insert('tbl_users',$data);
		$res = $db->getResult();

		$user_id = $res[0];

		$sql = "SELECT location.* FROM tbl_locations as location left outer join tbl_users user on location.user_id = user.id where user.medical_status = 1 or user.medical_status = 3";
		$db->sql($sql);
		$result = $db->getResult();
		if (!empty($result)) {
			if(isset($_FILES['file']['name']) && !empty($_FILES['file']['name'])) {
					$is_detected = false;
					$message = "";
			    	$name=$_FILES['file']['name'];
			    	$tmp_name=$_FILES['file']['tmp_name'];
			    	if(move_uploaded_file($tmp_name, $upload_directory.$name)) {
						$strJsonFileContents = file_get_contents($upload_directory.$name);
						$array = json_decode($strJsonFileContents, true);
						if (isset($array['timelineObjects'])) {
							$places = $array['timelineObjects'];
							foreach ($places as $key=>$place) {
								if(isset($place['placeVisit'])){
									$visits = $place['placeVisit'];

									$latitude = "";
									$longitude = "";

									$latitude = $visits['location']['latitudeE7'];
									$longitude = $visits['location']['longitudeE7'];

									$latitude = $latitude/10000000;
									$longitude = $longitude/10000000;

									foreach ($result as $value) {
										$mlatitude = "";
										$mlongitude = "";

										$mlatitude = $value['latitude'];
										$mlongitude = $value['longitude'];

										$distance = "";

										$distance = distance($latitude, $longitude, $mlatitude, $mlongitude, "M")*1000;
										if ($distance <= 10){
											$message =  "Possibility of Contact with Infected Person is Very High. Condition - Highly Sensitive"; 
											$match_person_id = $value['user_id'];
											$location_id = $value['id'];
											$sql = "INSERT INTO tbl_matches (user_id, matched_person_id, location_id, distance) VALUES (".$user_id." , ".$match_person_id." , ".$location_id.", '".$distance."')";
											$db->sql($sql);
											$is_detected = true;
										} else if ($distance <= 20 && $distance > 10 ){
											$message = "Possibility of Contact with Infected Person is high. Condition - Sensitive";
											$match_person_id = $value['user_id'];
											$location_id = $value['id'];
											$sql = "INSERT INTO tbl_matches (user_id, matched_person_id, location_id, distance) VALUES (".$user_id." , ".$match_person_id." , ".$location_id.", '".$distance."')";
											$db->sql($sql);
											//$user_id = available in request
											$is_detected = true;
										} else if ($distance <= 30 && $distance > 20 ){
											$message = "Possibility of Contact with Infected Person is low. Condition - less Sensitive";
											$match_person_id = $value['user_id'];
											$location_id = $value['id'];
											$sql = "INSERT INTO tbl_matches (user_id, matched_person_id, location_id, distance) VALUES (".$user_id." , ".$match_person_id." , ".$location_id.", '".$distance."')";
											$db->sql($sql);
											$is_detected = true;
										}
									}
								}
							}

							if ($is_detected) {
								$response['error'] = "false";
								$response['message'] = $message;
								$response['is_infacted'] = $is_detected;
								$response['user_id'] = $user_id;
							} else {
								$response['error'] = "false";
								$response['message'] = "Possibility of Contact with Infected Person is very low. System cannot inspect the condition.";
								$response['is_infacted'] = $is_detected;
								$response['user_id'] = $user_id;
							}
						} else {
							$response['error'] = "true";
							$response['message'] = "File data incorrect";
						}
					} else {
						$response['error'] = "true";
						$response['message'] = "Unable to process your file";
					}
				} else {
				$response['error'] = "true";
				$response['message'] = "No valid file found";
			}
		} else {
			$response['error'] = "true";
			$response['message'] = "No data found!";
		}
		print_r(json_encode($response));
	} 
	if(isset($_POST['upload_confirmed_data']) AND $_POST['upload_confirmed_data']==1) {
		//$tableNameUser = 'tbl_users';
		$tableName = 'tbl_locations';
		$collumns = array('user_id', 'place_name', 'latitude', 'longitude', 'address', 'startTimestampMs', 'endTimestampMs');
		$collunNames = implode(', ',$collumns);

		$query = 'INSERT INTO ' .$tableName. ' ('. $collunNames .' ) values ';

		if (!isset($_POST['person_name']) || empty($_POST['person_name']) 
			|| !isset($_POST['person_mobile_no']) || empty($_POST['person_mobile_no']) 
			|| !isset($_POST['person_age']) || empty($_POST['person_age']) 
			|| !isset($_POST['person_address']) || empty($_POST['person_address']) 
			|| !isset($_POST['doctor_name']) || empty($_POST['doctor_name']) 
			|| !isset($_POST['hospital_name']) || empty($_POST['hospital_name']) 
			|| !isset($_FILES['file']['name']) || empty($_FILES['file']['name'])) {

			$response['error'] = "true";
			$response['message'] = "All fields are required.";
			print_r(json_encode($response));
			return;
		}

		$person_name = $db->escapeString($_POST['person_name']);
		$person_mobile_no = $db->escapeString($_POST['person_mobile_no']);
		$person_age = $db->escapeString($_POST['person_age']);
		$person_address = $db->escapeString($_POST['person_address']);
		$doctor_name = $db->escapeString($_POST['doctor_name']);
		$hospital_name = $db->escapeString($_POST['hospital_name']);

		$data = array(
				'name'  => $person_name,
				'age'	 => $person_age,
				'mobile_no' => $person_mobile_no,
				'address' => $person_address,
				'doctor_name'	 => $doctor_name,
				'hospital_name' => $hospital_name,
				'medical_status' => '1'
			);
		$sql = $db->insert('tbl_users',$data);
		$res = $db->getResult();

		$user_id = $res[0];

		if(isset($_FILES['file']['name']) && !empty($_FILES['file']['name'])) {
	    	$name=$_FILES['file']['name'];
	    	$tmp_name=$_FILES['file']['tmp_name'];

	    	if(move_uploaded_file($tmp_name, $upload_directory.$name)) {

				$strJsonFileContents = file_get_contents($upload_directory.$name);
				$array = json_decode($strJsonFileContents, true);
				$places = $array['timelineObjects'];

				foreach ($places as $key=>$place) {
					if(isset($place['placeVisit'])){
						$visits = $place['placeVisit'];
						$q1 = ' (';

						$latitude = $db->escapeString($visits['location']['latitudeE7']);
						$longitude = $db->escapeString($visits['location']['longitudeE7']);
						$address = $db->escapeString($visits['location']['address']);
						$placeName = $db->escapeString($visits['location']['name']);

						$startTimestampMs = $db->escapeString($visits['duration']['startTimestampMs']);
						$endTimestampMs = $db->escapeString($visits['duration']['endTimestampMs']);

						$latitude = $latitude/10000000;
						$longitude = $longitude/10000000;

						$q1 = $q1 . $user_id. ', \''. $placeName. '\', \'' .$latitude. '\', \'' .$longitude. '\', \'' .$address. '\', \'' .$startTimestampMs. '\', \'' .$endTimestampMs. '\''; 

						$q1 = $q1 . '), ';

						$query = $query . $q1;

						/*echo $key.";;".$visits['location']['latitudeE7'];
						echo '<br>';*/
					}
				}
				$query = substr($query,0,-2);
				//$query = $db->escapeString($query);
				$db->sql($query);
				$result = $db->getResult();
				$response['error'] = "false";
				$response['result'] = "Data Uploaded Successfully";
				//$response['query'] = $query;
			}else {
				$response['error'] = "true";
				$response['message'] = "File Not Able to Upload";
			}

		}
		print_r(json_encode($response));
	}

	if(isset($_POST['get_matched_points']) AND $_POST['get_matched_points']==1) {

		$limit = (isset($_POST['limit']) && !empty($_POST['limit']) && is_numeric($_POST['limit']))?$db->escapeString($_POST['limit']):25;
		$offset = (isset($_POST['offset']) && !empty($_POST['offset']) && is_numeric($_POST['offset']))?$db->escapeString($_POST['offset']):0;
	
		if (!isset($_POST['user_id']) || empty($_POST['user_id'])) {
			$response['error'] = "true";
			$response['message'] = "All fields are required.";
			print_r(json_encode($response));
			return;
		}	

		$user_id = $db->escapeString($_POST['user_id']);

		$sql = "SELECT count(tbl_matches.id) as total FROM tbl_matches left outer join tbl_locations on tbl_matches.location_id=tbl_locations.id where tbl_matches.user_id=$user_id order by tbl_locations.startTimestampMs desc";
		$db->sql($sql);
		$total = $db->getResult();

		$sql = "SELECT u1.name personName, l.startTimestampMs as locationDate, concat(l.place_name, ', ', l.address) as placeAndAddress, concat(u1.doctor_name, ', ', u1.hospital_name) as doctorNameAndHospital, ROUND(m.distance, 2) as distance FROM tbl_matches m left outer join tbl_locations l on m.location_id=l.id left outer join tbl_users as u1 on m.matched_person_id = u1.id where m.user_id=$user_id  order by l.startTimestampMs desc LIMIT $offset,$limit";
		$db->sql($sql);
		$res = $db->getResult();

		if(!empty($res)){
			$response['error'] = "false";
			$response['total'] = $total[0]['total'];
			$response['data'] = $res;
			print_r(json_encode($response));
		} else {
			$response['error'] = "true";
			$response['message'] = "Data not found";
			print_r(json_encode($response));
		}
	}
?>