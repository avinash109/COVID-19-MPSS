
Ext.application({
    name: 'Traccar',
    extend: 'Traccar.Application'
});
